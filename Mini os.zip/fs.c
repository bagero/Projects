/* Sistemas Operativos, DEI/IST/ULisboa 2019-20 */

#include "fs.h"
#include "lib/bst.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "sync.h"
#include "lib/hash.h"


int numberB = 0;

int obtainNewInumber(tecnicofs* fs) {
	int newInumber = ++(fs->nextINumber);
	return newInumber;
}

tecnicofs* new_tecnicofs(int numberBuckets){
	numberB = numberBuckets;
	int i;
	tecnicofs*fs = malloc(sizeof(tecnicofs));
	fs->bstRoot = malloc(sizeof(node*) * numberB);
	if (!fs) {
		perror("failed to allocate tecnicofs");
		exit(EXIT_FAILURE);
	}

	for (i = 0; i < numberB; i++){
        fs->bstRoot[i] = NULL;
    }
	fs->nextINumber = 0;
	sync_init(&(fs->bstLock));
	return fs;
}

void free_tecnicofs(tecnicofs* fs){
	int i;
	for(i = 0; i < numberB; i++){
		free_tree(fs->bstRoot[i]);
	}
	sync_destroy(&(fs->bstLock));
	free(fs->bstRoot);
	free(fs);
}

void create(tecnicofs* fs, char *name, int inumber){
	sync_wrlock(&(fs->bstLock));
	int bucket = hash(name, numberB);
	fs->bstRoot[bucket] = insert(fs->bstRoot[bucket], name, inumber);
	sync_unlock(&(fs->bstLock));
}

void delete(tecnicofs* fs, char *name){
	sync_wrlock(&(fs->bstLock));
	int bucket = hash(name, numberB);
	fs->bstRoot[bucket] = remove_item(fs->bstRoot[bucket], name);
	sync_unlock(&(fs->bstLock));
}

int lookup(tecnicofs* fs, char *name){
	sync_rdlock(&(fs->bstLock));
	int inumber = 0;
	int bucket = hash(name, numberB);
	node* searchNode = search(fs->bstRoot[bucket], name);
	if ( searchNode ) {
		inumber = searchNode->inumber;
	}
	sync_unlock(&(fs->bstLock));
	return inumber;
}

void renameFile(tecnicofs* fs, char *name, char *newName){
	int searchResult1 = lookup(fs, name);
    int searchResult2 = lookup(fs, newName);
    if (!searchResult1 || searchResult2)
        return;

    delete(fs, name);
    create(fs, newName, searchResult1);
}

void print_tecnicofs_tree(FILE * fp, tecnicofs *fs){
	int i;
	for(i = 0; i < numberB; i++){
		print_tree(fp, fs->bstRoot[i]);
	} 
}
